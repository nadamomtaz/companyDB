﻿using System;
using System.Collections.Generic;

namespace CompanySystemDB.Models;

public partial class WorksOn
{
    public int EmployeeSsn { get; set; }

    public int ProjectPnumber { get; set; }

    public int? Hours { get; set; }

    public virtual Employee EmployeeSsnNavigation { get; set; } = null!;

    public virtual Project ProjectPnumberNavigation { get; set; } = null!;
}
