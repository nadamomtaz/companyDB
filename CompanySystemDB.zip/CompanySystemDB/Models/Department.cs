﻿using System;
using System.Collections.Generic;

namespace CompanySystemDB.Models;

public partial class Department
{
    public int Dnum { get; set; }

    public string Dname { get; set; } = null!;

    public string? Locations { get; set; }

    public int? ManagerSsn { get; set; }

    public DateOnly? ManagerHiringDate { get; set; }

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();

    public virtual Employee? ManagerSsnNavigation { get; set; }

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();
}
