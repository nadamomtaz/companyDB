﻿using System;
using System.Collections.Generic;

namespace CompanySystemDB.Models;

public partial class Project
{
    public int Pnumber { get; set; }

    public string Pname { get; set; } = null!;

    public string? Location { get; set; }

    public string? City { get; set; }

    public int DepartmentDnum { get; set; }

    public virtual Department DepartmentDnumNavigation { get; set; } = null!;

    public virtual ICollection<WorksOn> WorksOns { get; set; } = new List<WorksOn>();
}
