﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CompanySystemDB.Models;

public partial class CompanyDb2Context : DbContext
{
    public CompanyDb2Context()
    {
    }

    public CompanyDb2Context(DbContextOptions<CompanyDb2Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Dependent> Dependents { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Project> Projects { get; set; }

    public virtual DbSet<WorksOn> WorksOns { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\MSSQLSERVER01;Database=CompanyDB2;Integrated Security=SSPI;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.Dnum).HasName("PK__Departme__24BF7757248207B8");

            entity.ToTable("Department");

            entity.Property(e => e.Dnum)
                .ValueGeneratedNever()
                .HasColumnName("DNUM");
            entity.Property(e => e.Dname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("DName");
            entity.Property(e => e.Locations)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.ManagerSsn).HasColumnName("ManagerSSN");

            entity.HasOne(d => d.ManagerSsnNavigation).WithMany(p => p.Departments)
                .HasForeignKey(d => d.ManagerSsn)
                .HasConstraintName("FK__Departmen__Manag__5812160E");
        });

        modelBuilder.Entity<Dependent>(entity =>
        {
            entity.HasKey(e => new { e.DependentName, e.EmployeeSsn }).HasName("PK__Dependen__625CDAD2B0A6AEE3");

            entity.ToTable("Dependent");

            entity.Property(e => e.DependentName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeSsn).HasColumnName("EmployeeSSN");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();

            entity.HasOne(d => d.EmployeeSsnNavigation).WithMany(p => p.Dependents)
                .HasForeignKey(d => d.EmployeeSsn)
                .HasConstraintName("FK__Dependent__Emplo__534D60F1");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Ssn).HasName("PK__Employee__CA1E8E3D055EB1B2");

            entity.ToTable("Employee");

            entity.Property(e => e.Ssn)
                .ValueGeneratedNever()
                .HasColumnName("SSN");
            entity.Property(e => e.DepartmentDnum).HasColumnName("DepartmentDNUM");
            entity.Property(e => e.Fname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("FName");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Lname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("LName");

            entity.HasOne(d => d.DepartmentDnumNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.DepartmentDnum)
                .HasConstraintName("FK__Employee__Depart__4D94879B");
        });

        modelBuilder.Entity<Project>(entity =>
        {
            entity.HasKey(e => e.Pnumber).HasName("PK__Project__DDE0878D4582168A");

            entity.ToTable("Project");

            entity.Property(e => e.Pnumber)
                .ValueGeneratedNever()
                .HasColumnName("PNumber");
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DepartmentDnum).HasColumnName("DepartmentDNUM");
            entity.Property(e => e.Location)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Pname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("PName");

            entity.HasOne(d => d.DepartmentDnumNavigation).WithMany(p => p.Projects)
                .HasForeignKey(d => d.DepartmentDnum)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Project__Departm__5070F446");
        });

        modelBuilder.Entity<WorksOn>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeSsn, e.ProjectPnumber }).HasName("PK__WorksOn__B3E12DBBE6855235");

            entity.ToTable("WorksOn");

            entity.Property(e => e.EmployeeSsn).HasColumnName("EmployeeSSN");
            entity.Property(e => e.ProjectPnumber).HasColumnName("ProjectPNumber");

            entity.HasOne(d => d.EmployeeSsnNavigation).WithMany(p => p.WorksOns)
                .HasForeignKey(d => d.EmployeeSsn)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__WorksOn__Employe__5629CD9C");

            entity.HasOne(d => d.ProjectPnumberNavigation).WithMany(p => p.WorksOns)
                .HasForeignKey(d => d.ProjectPnumber)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__WorksOn__Project__571DF1D5");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
