﻿using System;
using System.Collections.Generic;

namespace CompanySystemDB.Models;

public partial class Employee
{
    public int Ssn { get; set; }

    public string Fname { get; set; } = null!;

    public string Lname { get; set; } = null!;

    public DateOnly? BirthDate { get; set; }

    public string? Gender { get; set; }

    public int? DepartmentDnum { get; set; }

    public virtual Department? DepartmentDnumNavigation { get; set; }

    public virtual ICollection<Department> Departments { get; set; } = new List<Department>();

    public virtual ICollection<Dependent> Dependents { get; set; } = new List<Dependent>();

    public virtual ICollection<WorksOn> WorksOns { get; set; } = new List<WorksOn>();
}
