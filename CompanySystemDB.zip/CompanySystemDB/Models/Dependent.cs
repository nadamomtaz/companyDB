﻿using System;
using System.Collections.Generic;

namespace CompanySystemDB.Models;

public partial class Dependent
{
    public string DependentName { get; set; } = null!;

    public int EmployeeSsn { get; set; }

    public string? Gender { get; set; }

    public DateOnly? BirthDate { get; set; }

    public virtual Employee EmployeeSsnNavigation { get; set; } = null!;
}
