﻿using CompanySystemDB.Models;

namespace CompanySystemDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using var context = new CompanyDb2Context();

            if (!context.Departments.Any())
            {
                context.Departments.AddRange(
                    new Department { Dnum = 1, Dname = "Research", Locations = "Cairo" },
                    new Department { Dnum = 2, Dname = "HR", Locations = "Alex" },
                    new Department { Dnum = 3, Dname = "IT", Locations = "Giza" },
                    new Department { Dnum = 4, Dname = "Finance", Locations = "Cairo" }
                );
                context.SaveChanges();
                Console.WriteLine("Departments added!");
            }
            Console.WriteLine("\nWhat do you want to do?");
            Console.WriteLine("1 - Add Employees");
            Console.WriteLine("2 - Update Employee");
            Console.Write("Enter choice: ");
            var choice = Console.ReadLine();

            if (choice == "1")
            {
                Console.Write("How many employees do you want to add? ");
                int count = int.Parse(Console.ReadLine());

                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine($"\nEmployee {i + 1}:");

                    Console.Write("SSN: ");
                    int ssn = int.Parse(Console.ReadLine());

                    Console.Write("First Name: ");
                    string fname = Console.ReadLine();

                    Console.Write("Last Name: ");
                    string lname = Console.ReadLine();

                    Console.Write("Gender (M/F): ");
                    string gender = Console.ReadLine();

                    Console.Write("Department Number (1-4): ");
                    int dnum = int.Parse(Console.ReadLine());

                    context.Employees.Add(new Employee
                    {
                        Ssn = ssn,
                        Fname = fname,
                        Lname = lname,
                        Gender = gender,
                        BirthDate = new DateOnly(2000, 1, 1),
                        DepartmentDnum = dnum
                    });
                    context.SaveChanges();
                    Console.WriteLine("Employee added!");
                }
            }
            else if (choice == "2")
            {
                Console.Write("Enter Employee SSN to update: ");
                int ssn = int.Parse(Console.ReadLine());

                var emp = context.Employees.Find(ssn);
                if (emp != null)
                {
                    Console.Write("New First Name: ");
                    emp.Fname = Console.ReadLine();

                    Console.Write("New Last Name: ");
                    emp.Lname = Console.ReadLine();

                    context.SaveChanges();
                    Console.WriteLine("Employee updated!");
                }
                else
                {
                    Console.WriteLine("Employee not found!");
                }
            }
            Console.WriteLine("\n--- All Employees ---");
            var employees = context.Employees.ToList();
            foreach (var e in employees)
                Console.WriteLine($"SSN: {e.Ssn} | Name: {e.Fname} {e.Lname} | Gender: {e.Gender} | Dept: {e.DepartmentDnum}");
        }
    }
}
